### Steps to use

```bash
npm install
node index.js <<public-key.pem>> true
```